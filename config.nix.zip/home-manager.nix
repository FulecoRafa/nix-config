{ inputs, ... }:

{
  import = [
    inputs.home-manager.nixosModules.home-manager
  ];

  home-manager.useGlobalPkgs = true;

  home-manager.users.fuleco = {pkgs, ...}: {
    programs.home-manager.enable = true;

    imports = [
      ./termapps/fastfetch
    ];
    home.packages = with pkgs; [
    ];
  };
}
